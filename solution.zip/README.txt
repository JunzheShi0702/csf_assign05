Sample README.txt
MileStone 1
Junzhe: Project setup, connection.cpp setup, receiver coding and debugging
Albert: Sender coding and debugging

Eventually your report about how you implemented thread synchronization
in the server should go here
